"""Virtual Gallery Studio. Python 3.9+, Git and authenticated GitHub CLI."""

import ssl, datetime, math, http.cookies, json, mimetypes, os, pathlib, re, secrets, subprocess, tempfile, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = pathlib.Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
DATA = ROOT / "private"
DATA.mkdir(mode=0o700, exist_ok=True)
REPO = "https://github.com/jyunhao914/jyunhao914.github.io.git"
SESSION = secrets.token_urlsafe(32)
LOGIN = secrets.token_urlsafe(24)
lock = threading.RLock()


def write(path, value):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def initial():
    shows = json.loads((PUBLIC / "exhibitions.json").read_text())
    art = {}
    for s in shows:
        for a in s["works"]:
            art[a["id"]] = a
        s["ids"] = [a["id"] for a in s.pop("works")]
        s.update(status="已發布", layout={})
    return dict(rev=0, arts=list(art.values()), shows=shows)


db = DATA / "studio.json"
if not db.exists():
    write(db, initial())


def read():
    return json.loads(db.read_text())


def save(s):
    old = read()
    if old["rev"] != s["rev"]:
        raise ValueError("資料已有新版，請重新載入後再修改。")
    validate(s)
    write(DATA / ("v%d.json" % old["rev"]), old)
    s["rev"] += 1
    write(db, s)
    return s["rev"]


def validate(s):
    for key in ["arts", "shows"]:
        items = s[key]
        if not isinstance(items, list) or len({a["id"] for a in items}) != len(items):
            raise ValueError("重複或無效的識別碼")

    def check_layout(a, partial=False):
        bounds = {
            "wall": (0, 3),
            "x": (-100, 100),
            "y": (0, 4.5),
            "z": (0, 3),
            "width": (0.05, 100),
            "height": (0.05, 4.5),
            "rotate": (-180, 180),
            "mat": (0, 0.5),
            "depth": (0.01, 0.5),
            "frameWidth": (0, 0.5),
            "lx": (-4, 4),
            "ly": (-2, 4),
            "lz": (0.1, 6),
            "power": (0, 120),
            "kelvin": (2500, 7000),
            "angle": (5, 85),
        }
        for k, (low, high) in bounds.items():
            if partial and k not in a:
                continue
            v = a[k]
            if (
                type(v) not in (float, int)
                or not low <= v <= high
                or k == "wall"
                and type(v) != int
            ):
                raise ValueError("布展參數無效：" + k)
        if not partial or "room" in a:
            if not isinstance(a["room"], str) or not a["room"].strip():
                raise ValueError("請填寫展廳名稱")

    for item in s["arts"] + s["shows"]:
        if not re.fullmatch("[A-Za-z0-9_-]{1,80}", item["id"]):
            raise ValueError("識別碼格式錯誤")
    for a in s["arts"]:
        if not a["title"].strip() or a["type"] not in [
            "圖片",
            "文字",
            "語音",
            "影片",
            "動態",
        ]:
            raise ValueError("請填寫作品名稱及類型")
        check_layout(a)
        if not isinstance(a["src"], str):
            raise ValueError("無效的媒體資料")
    for x in s["shows"]:
        for layout in x["layout"].values():
            check_layout(layout, True)
        if (
            not isinstance(x["playlist"], list)
            or not 0 <= x["volume"] <= 1
            or not 0 <= x["fade"] <= 30
        ):
            raise ValueError("播放清單設定無效")
        if (
            not x["title"].strip()
            or x.get("start")
            and x.get("end")
            and x["end"] < x["start"]
        ):
            raise ValueError("展名或檔期無效")
        for k in ["start", "end"]:
            if x.get(k):
                datetime.date.fromisoformat(x[k])
        if set(x["ids"]) - set(a["id"] for a in s["arts"]):
            raise ValueError("展覽引用缺少的作品")


fields = "id title artist category type description src mount tiles source voice captions subtitle room wall x y z width height rotate frame frameWidth mat depth finish kelvin power angle lx ly lz".split()


def project(s, x):
    out = {
        k: x[k] for k in "id title description start end playlist volume fade".split()
    }
    by = {a["id"]: a for a in s["arts"]}
    out["works"] = []

    def media(v):
        if (
            not v
            or re.fullmatch(r"media/[A-Za-z0-9_-]+\.(webp|mp4|mp3)", v)
            and (PUBLIC / v).is_file()
        ):
            return
        if not re.fullmatch(
            r"data:(?:image/(?:jpeg|png|webp|gif|avif)|video/(?:mp4|webm|quicktime)|audio/[\w.+-]+|text/vtt)(?:;charset=[\w-]+)?;base64,[A-Za-z0-9+/=\s]+",
            v,
        ):
            raise ValueError("不支援的媒體格式")

    for v in out["playlist"]:
        media(v)
    for i in x["ids"]:
        a = {**by[i], **x.get("layout", {}).get(i, {})}
        for k in ["src", "voice", "captions"]:
            media(a.get(k, ""))
        out["works"].append({k: a[k] for k in fields if k in a})
    return out


def deploy(s, x, end):
    payload = project(s, x)
    today = (
        (datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))))
        .date()
        .isoformat()
    )
    if not end and not x["ids"]:
        raise ValueError("請先選擇展出作品")
    if not end and (
        (x["start"] and today < x["start"]) or (x["end"] and today > x["end"])
    ):
        raise ValueError("請於展期內發布，未到期素材保留在本機。")
    with tempfile.TemporaryDirectory() as folder:

        def git(*args):
            subprocess.run(
                [
                    "git",
                    "-c",
                    "credential.helper=",
                    "-c",
                    "credential.helper=!gh auth git-credential",
                    *args,
                ],
                cwd=folder,
                check=True,
                timeout=180,
                capture_output=True,
            )

        git("clone", "--depth", "1", "--branch", "main", REPO, ".")
        path = pathlib.Path(folder) / "virtual-gallery/exhibitions.json"
        items = [a for a in json.loads(path.read_text()) if a["id"] != x["id"]]
        if not end:
            items.insert(0, payload)
        write(path, items)
        if path.stat().st_size > 90_000_000:
            raise ValueError("展覽檔超過 90 MB，請壓縮影音後再發布")
        git("add", "--", "virtual-gallery/exhibitions.json")
        if subprocess.run(
            ["git", "diff", "--cached", "--quiet"], cwd=folder
        ).returncode:
            git(
                "-c",
                "user.name=Virtual Gallery Studio",
                "-c",
                "user.email=studio@users.noreply.github.com",
                "commit",
                "-m",
                "Update selected public exhibition",
            )
            git("push", "origin", "HEAD:main")
    x["status"] = "歷史典藏" if end else "已發布"
    return save(s)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def respond(self, value, kind="application/json", status=200, cookie=False):
        data = (
            value
            if isinstance(value, bytes)
            else json.dumps(value, ensure_ascii=False).encode()
        )
        self.send_response(status)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if cookie:
            self.send_header(
                "Set-Cookie",
                "studio="
                + SESSION
                + "; HttpOnly; SameSite=Strict; Path=/"
                + ("; Secure" if isinstance(self.connection, ssl.SSLSocket) else ""),
            )
        self.end_headers()
        self.wfile.write(data)

    def ok(self):
        cookie = http.cookies.SimpleCookie(self.headers.get("Cookie", ""))
        return secrets.compare_digest(
            cookie.get("studio").value if "studio" in cookie else "", SESSION
        )

    def do_GET(self):
        p = urlsplit(self.path).path
        if p == "/":
            return self.respond((ROOT / "studio.html").read_bytes(), "text/html")
        if not self.ok():
            return self.respond("請先登入", "application/json", 401)
        try:
            if p == "/api/state":
                return self.respond(read())
            if p == "/api/versions":
                return self.respond(
                    sorted(
                        [int(f.stem[1:]) for f in DATA.glob("v*.json")], reverse=True
                    )
                )
            if p.startswith("/preview/") and p.endswith("/exhibitions.json"):
                s = read()
                x = next(a for a in s["shows"] if a["id"] == p.split("/")[2])
                view = project(s, x)
                view.update(start="", end="")
                return self.respond([view])
            if p == "/studio.js":
                f = ROOT / "studio.js"
            else:
                rel = re.sub(r"^/(?:preview/[^/]+/|public/)", "", p) or "index.html"
                f = (PUBLIC / rel).resolve()
                if PUBLIC not in f.parents:
                    raise ValueError()
            self.respond(
                f.read_bytes(), mimetypes.guess_type(f)[0] or "application/octet-stream"
            )
        except Exception:
            self.respond("找不到資源", status=404)

    def do_POST(self):
        global LOGIN
        if self.headers.get("Origin") != (
            "https://" if isinstance(self.connection, ssl.SSLSocket) else "http://"
        ) + self.headers.get("Host", "") or not self.headers.get(
            "Content-Type", ""
        ).startswith(
            "application/json"
        ):
            return self.respond("來源不符", status=403)
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > 200_000_000:
                raise ValueError("資料超過 200 MB")
            body = json.loads(self.rfile.read(n))
            with lock:
                if (
                    self.path == "/api/login"
                    and LOGIN
                    and secrets.compare_digest(body["key"], LOGIN)
                ):
                    LOGIN = None
                    return self.respond(True, cookie=True)
                if not self.ok():
                    return self.respond("登入碼無效", status=403)
                if self.path == "/api/save":
                    return self.respond(save(body))
                if self.path == "/api/restore":
                    s = json.loads(
                        (DATA / ("v%d.json" % int(body["version"]))).read_text()
                    )
                    s["rev"] = body["rev"]
                    return self.respond(save(s))
                if self.path in ["/api/publish", "/api/end"]:
                    s = read()
                    if body["rev"] != s["rev"]:
                        raise ValueError("請重新載入最新版本")
                    x = next(a for a in s["shows"] if a["id"] == body["id"])
                    return self.respond(deploy(s, x, self.path.endswith("/end")))
                self.respond("無此操作", status=404)
        except subprocess.SubprocessError:
            self.respond(
                "Git 發布失敗。請確認 gh auth status、網路及 main 分支寫入權限，再重試。",
                status=409,
            )
        except Exception as e:
            self.respond(str(e), status=400)


if __name__ == "__main__":
    host = os.environ.get("STUDIO_HOST", "127.0.0.1")
    tls = bool(os.environ.get("STUDIO_CERT"))
    if host != "127.0.0.1" and not tls:
        raise SystemExit("區域網路連線須提供 STUDIO_CERT 與 STUDIO_KEY")
    srv = ThreadingHTTPServer(
        (host, int(os.environ.get("STUDIO_PORT", "8765"))), Handler
    )
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(os.environ["STUDIO_CERT"], os.environ["STUDIO_KEY"])
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    port = srv.server_port
    url = ("https" if tls else "http") + f"://{host}:{port}/#" + LOGIN
    print("本機工作室一次性登入連結　" + url, flush=True)
    if not os.environ.get("STUDIO_NO_OPEN"):
        webbrowser.open(url)
    srv.serve_forever()
